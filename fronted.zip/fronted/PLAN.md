# Plan: Real-Time Restaurant Project

> **Purpose:** Persist a single source of truth so any agent (or developer) can pick this up, execute the next step, and check it off. Update this file — do not edit tasks in chat — so progress survives across sessions.

> **Rules of engagement**
> - Work through steps **in order** unless marked parallelizable.
> - Mark a step `[x]` only after its verification command(s) pass.
> - Re-run `npm run lint`, `npx tsc --noEmit`, and `npm run build` after each cluster.
> - **Do not commit** unless explicitly asked.

---

## Reference Docs

- `AGENTS.md` — project primer, tech stack, architecture conventions, Next.js 16 breaking changes, current roadmap.
- `README.md` — public-facing overview and dev commands.
- `node_modules/next/dist/docs/` — bundled Next.js 16 docs (especially `01-app/02-guides/upgrading/version-16.md`).

---

## Visual Design

The app uses an **Aurora UI** aesthetic — deep dark backgrounds, glass morphism, vibrant aurora-colored accents (teal `#14b8a6`, purple `#a855f7`, blue `#3b82f6`, pink `#ec4899`).

**Dark mode** is the default. Toggle available in Topbar (sun/moon icon). Persisted in `localStorage` key `"theme"`.

All aurora CSS classes are defined in `app/globals.css` as CSS custom properties. See `AGENTS.md` for the full color system and class reference.

---

## Auth & Roles

3 seeded users (password = email prefix, e.g. `admin@demo.com` / `admin`):

| Email | Role | Label |
|---|---|---|
| `admin@demo.com` | admin | Admin |
| `manager@demo.com` | manager | Manager |
| `waitress@demo.com` | waitress | Waitress |

Permission matrix in `app/services/roles.ts` (12 actions × 3 roles). UI gating via `<Can action="...">` component or `can(role, action)` utility.

---

## Routes

| Route | Component | Access |
|---|---|---|
| `/` | Redirects → `/tables` (auth) or `/login` | Public |
| `/login` | LoginPage + LoginForm | Public |
| `/tables` | TablesPage → VisualTableGrid → VisualTableCard | All roles |
| `/tables/[id]` | Per-table detail with order actions | All roles |
| `/dashboard` | Dashboard with stat cards | All roles |
| `/staff` | WaitressPage with add/delete | Admin, Manager |
| `/settings` | SettingsPage | Admin |

---

## Progress Summary

| Step | Status |
|---|---|
| 1. Re-audit | [x] |
| 2. Clarify with user | [x] |
| 3. Naming/config drift | [x] |
| 4. Replace boilerplate | [x] |
| 5. Reconcile dashboard stubs | [x] |
| 6. Wire folder scaffolding | [x] |
| 7. Documentation | [x] |
| 8. Aurora UI + dark mode | [x] |
| 9. Waitress page (add/delete dialogs) | [x] |
| 10. Verify & commit-prep | [x] |

---

## Next Steps

- Real authentication backend (session/JWT)
- Real REST/real-time API wiring (WebSocket/SSE for live orders)
- Menu / orders screens
- Persistent database (currently in-memory, resets on restart)