<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
dont commit any change, ask the user to do it
<!-- END:nextjs-agent-rules -->

# Real-Time Restaurant

A real-time restaurant management dashboard built with Next.js 16 (App Router), React 19, TypeScript, and Tailwind CSS v4. Organized as a **Feature-Driven Architecture** — routing lives in `src/app/`, business logic lives in `src/features/`, and cross-cutting code lives in `src/shared/`.

## Visual Design

The app uses an **Aurora UI** aesthetic with deep dark backgrounds and vibrant aurora-colored accents (teal, purple, blue, pink). All components are styled via CSS custom properties defined in `app/globals.css`.

### Color System
| Token | Dark mode | Light mode | Usage |
|---|---|---|---|
| `--aurora-1` | `#14b8a6` | `#0d9488` | Primary accent (teal) |
| `--aurora-2` | `#a855f7` | `#9333ea` | Secondary accent (purple) |
| `--aurora-3` | `#3b82f6` | `#2563eb` | Blue |
| `--aurora-4` | `#ec4899` | `#db2777` | Pink |
| `--background` | `#020617` | `#f0fdfa` | Page background |
| `--card-bg` | `rgba(15,23,42,0.6)` | `rgba(255,255,255,0.75)` | Glass cards |
| `--text-primary` | `#f8fafc` | `#0f172a` | Body text |
| `--glass-border` | `rgba(255,255,255,0.1)` | `rgba(0,0,0,0.06)` | Card borders |

### Dark Mode
- Controlled by `ThemeContext` (`src/shared/contexts/ThemeContext.tsx`)
- Persisted in `localStorage` key `"theme"`
- Toggle button in Topbar (sun/moon icon)
- `html` element gets `dark` or `light` class
- All aurora CSS classes adapt via `.light` selector

### Aurora CSS Classes
| Class | Purpose |
|---|---|
| `aurora-card` | Glass card with blur, glow, hover lift |
| `aurora-btn-primary` | Gradient teal→purple button |
| `aurora-btn-ghost` | Ghost button with border |
| `aurora-btn-danger` | Red-tinted danger button |
| `aurora-input` | Glass input with teal focus ring |
| `aurora-select` | Glass select with chevron |
| `aurora-label` | Small uppercase label |
| `aurora-badge` | Pill badge with tone variants |
| `aurora-dialog-panel` | Blurred floating dialog |
| `aurora-sidebar` | Dark glass sidebar with nav links |
| `aurora-topbar` | Top navigation bar |
| `aurora-theme-toggle` | Theme switch button |
| `aurora-table-row` | Table row with glass background |
| `aurora-avatar` | Gradient circle with initials |

### Components
- **Dialog** (`src/shared/components/ui/Dialog.tsx`) — portal-based modal with overlay, title, body, footer slots
- **VisualTableCard** — table card with SVG table illustration, status badge, order totals
- **WaitressPage** — staff management client component with add/delete dialogs

## Tech Stack

| Layer        | Technology                                     |
| ------------ | ---------------------------------------------- |
| Framework    | Next.js 16.2.9 (App Router, Turbopack default) |
| UI           | React 19.2, Tailwind CSS v4                    |
| Language     | TypeScript 5                                   |
| Linting      | ESLint 9 (flat config, `eslint-config-next`)   |
| Package Mgr  | npm                                            |
| Fonts        | Geist & Geist Mono (via `next/font/google`)     |

## Development Commands

```bash
npm run dev     # Start dev server (Turbopack by default) → http://localhost:3000
npm run build   # Production build (Turbopack by default, use --webpack to opt out)
npm run start   # Start production server
npm run lint    # Run ESLint (note: `next lint` is REMOVED in v16 — use eslint directly)
```

## Project Structure

```
real-time-restuarant/
├── src/
│   ├── app/                    # Next.js App Router — routing only
│   │   ├── globals.css         # Tailwind import + CSS variables
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # Home page (/)
│   │   ├── dashboard/          # /dashboard route → page.tsx
│   │   ├── login/              # /login route → page.tsx
│   │   ├── menu/               # /menu route → page.tsx
│   │   ├── settings/           # /settings route → page.tsx
│   │   ├── staff/              # /staff route → page.tsx
│   │   └── tables/             # /tables + /tables/[id] routes
│   │       └── [id]/page.tsx
│   ├── features/               # Feature modules with co-located business logic
│   │   ├── auth/               # LoginPage, LoginForm
│   │   ├── dashboard/          # Dashboard, SalesCard
│   │   ├── menu/               # MenuPage, dialogs, menuItems service
│   │   ├── orders/             # orders service (co-located)
│   │   ├── settings/           # SettingsPage
│   │   ├── staff/              # WaitressPage, dialogs, waitresses service
│   │   └── tables/             # TablesPage, visual components, tables service
│   ├── shared/                 # Cross-cutting shared code
│   │   ├── components/
│   │   │   ├── ui/             # UI primitives (Button, Card, Dialog, Input, Table, Badge, Can)
│   │   │   └── layout/         # Layout components (Sidebar, Topbar, DashboardShell)
│   │   ├── contexts/           # React context providers (Auth, Theme, Toast)
│   │   ├── hooks/              # Custom React hooks
│   │   ├── lib/
│   │   │   ├── api/            # API client / fetch helpers
│   │   │   └── utils/          # Utility functions (cn, formatCurrency)
│   │   └── services/           # Cross-cutting services (roles, users, restaurants)
├── public/                     # Static assets
├── next.config.ts              # Next.js config
├── tsconfig.json               # TypeScript config (path alias @/* → ./src/*)
├── eslint.config.mjs           # ESLint flat config
├── postcss.config.mjs          # PostCSS (Tailwind v4 plugin)
└── package.json
```

## Architecture Conventions

### App Router Rules
- **Folders define routes.** A route becomes public only when a `page.tsx` (or `route.ts`) file is added.
- **Server Components by default.** Layouts and pages are Server Components. Add `"use client"` only when you need state, event handlers, lifecycle hooks, or browser APIs.
- **Context providers** must be Client Components — create a provider wrapper and import it into the root layout.
- **Colocation is safe** inside `app/` — non-`page`/`route` files are never routable.

### Path Alias
- `@/*` maps to `./src/*` — configured in `tsconfig.json`. Use `@/app/...` for routing imports, `@/features/...` for feature modules, `@/shared/...` for shared code.

### Code Style
- **No comments** unless explicitly requested.
- Follow existing patterns; check neighboring files before writing new code.
- Do not commit secrets or `.env*` files.

## Next.js 16 Critical Changes (affect this project)

> Full docs: `node_modules/next/dist/docs/`. Key upgrade guide: `01-app/02-guides/upgrading/version-16.md`.

### Async Request APIs (Breaking)
- `params` and `searchParams` in pages/layouts are now **Promises** — must `await` them.
- `cookies()`, `headers()`, `draftMode()` from `next/headers` must be `await`ed.
- Type helpers available globally after `next dev`/`next build`/`next typegen`: `PageProps<'/route'>`, `LayoutProps<'/route'>`, `RouteContext`.

```tsx
// Correct v16 pattern
export default async function Page({ params }: PageProps<'/dashboard'>) {
  const { id } = await params;
  // ...
}
```

### Middleware → Proxy (Breaking)
- `middleware.ts` is **deprecated** — renamed to `proxy.ts`. Use `export function proxy(...)` (or default export).
- Proxy defaults to the **Node.js runtime** (edge runtime not supported in proxy).
- Codemod: `npx @next/codemod@canary middleware-to-proxy .`

### Turbopack by Default
- `next dev` and `next build` use **Turbopack** by default (no flags needed).
- If you add a custom `webpack` config in `next.config.ts`, `next build` will fail unless you run `next build --webpack` or migrate.
- `experimental.turbopack` → top-level `turbopack` option in `next.config.ts`.

### `next lint` Removed
- The `next lint` command is **gone**. This project already uses `eslint` directly (`npm run lint`).
- `next build` no longer runs linting.

### Image Changes (Breaking)
- `next/image` `priority` prop → **deprecated**, use `preload` instead.
- Default `qualities` is `[75]` only; `minimumCacheTTL` default is now `4 hours`; `imageSizes` no longer includes `16`.
- `images.domains` → deprecated, use `images.remotePatterns`.

### Cache Components (New, optional)
- Enable with `cacheComponents: true` in `next.config.ts` — unifies PPR, `use cache` directive, and `dynamicIO`.
- When enabled: route segment configs `dynamic`, `dynamicParams`, `revalidate`, `fetchCache` are **removed** — use `use cache` and `cacheLife` instead.
- `cacheLife` and `cacheTag` are now stable (remove `unstable_` prefix).

### Scroll Behavior
- Next.js no longer overrides `scroll-behavior` during SPA transitions. Add `data-scroll-behavior="smooth"` to `<html>` to restore instant scroll-to-top.

### Other Removals
- AMP support fully removed.
- `serverRuntimeConfig` / `publicRuntimeConfig` removed — use `process.env` directly.
- Parallel route slots now **require** `default.js` files (build fails without them).
- Node.js 18 no longer supported (minimum 20.9.0).

## Current State & Roadmap

### Done
- [x] Next.js 16 project scaffolded (App Router, Tailwind v4, TypeScript)
- [x] Folder structure created for features-based architecture
- [x] `/dashboard` route stub with restaurant table
- [x] `app/features/dashboard/Dashboard.tsx` stat-card stub
- [x] `package.json` `name` corrected to `real-time-restaurant` (folder name unchanged)
- [x] Home page (`/`) landing screen with link to `/dashboard`
- [x] `app/layout.tsx` metadata updated; providers (`AuthProvider`, `ToastProvider`) wrapped at root
- [x] UI primitives scaffolded: `Button`, `Card`, `Input`, `Table` (`@/app/components/ui`)
- [x] Layout primitives: `Sidebar`, `Topbar`, `DashboardShell` (`@/app/components/layout`)
- [x] Data service: `app/services/restaurants.ts` with typed `Restaurant` + `getRestaurants()`
- [x] API client base: `app/lib/api/client.ts` (`apiFetch`, `ApiError`)
- [x] Utils: `cn`, `formatCurrency`, `formatNumber` (`@/app/lib/utils`)
- [x] Custom hook: `useRestaurants` (`@/app/hooks`)
- [x] Contexts: `AuthContext`, `ToastContext` wired in root layout
- [x] Login route at `/login` backed by `src/features/auth/LoginPage.tsx`
- [x] Settings route at `/settings` backed by `src/features/settings/SettingsPage.tsx`
- [x] Default boilerplate SVGs removed from `public/`
- [x] Aurora UI aesthetic — all components use aurora CSS classes
- [x] Dark/light mode via `ThemeContext`, toggle in Topbar, persisted in localStorage
- [x] `/` redirects to `/tables` if authenticated, else `/login`
- [x] Login redirects to `/tables` on success
- [x] Tables page redesigned — `VisualTableCard` grid with status + orders
- [x] `/staff` page — waitress management (admin/manager only)
  - `WaitressPage` client component with role check
  - `AddWaitressDialog` — full name, restaurant dropdown, working hours
  - `DeleteWaitressDialog` — confirm/cancel before removing waitress
  - `src/features/staff/waitresses.ts` — in-memory CRUD (4 seeded waitresses)
- [x] Migrated from `app/` to Feature-Driven Architecture (`src/app/`, `src/features/`, `src/shared/`)

### TODO (next steps)
- [ ] Real authentication backend (currently stub `signIn(email)` in `AuthContext`)
- [ ] Real REST/real-time API wiring (websocket/SSE for live orders, stock, staff)
- [ ] Implement menu / orders screens (sidebar links currently non-functional)

## Errors & Fix Log

### 2026-07-13 — Step 8 lint failures

**Errors found during `npm run lint`:**

1. `app/components/ui/Card.tsx:3` — `error: An interface declaring no members is equivalent to its supertype` (`@typescript-eslint/no-empty-object-type`). The file declared `interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}` purely to reuse `HTMLAttributes` props; the lint rule rejects empty interfaces.
2. `app/hooks/useRestaurants.ts:14–20` — `error: Calling setState synchronously within an effect can trigger cascading renders` (`react-hooks/set-state-in-effect`). The hook reset `data` to `initialData` inside `useEffect`, which is the exact anti-pattern the rule targets.
3. `app/hooks/useRestaurants.ts:14–16` — `warning: 'setIsLoading' / 'setError' assigned a value but never used` (`@typescript-eslint/no-unused-vars`). The hook kept setters for a future fetch/local state machine that never materialized.

**Fixes applied (verified — see verification cluster below):**

1. **Card.tsx:** replaced the empty `interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}` with a direct type alias `type CardProps = React.HTMLAttributes<HTMLDivElement>`. Same prop shape, lint-clean.
2. **useRestaurants.ts:** dropped the `useEffect` entirely (no longer needed — consumer passes `initialData` straight into a `useState` initializer so the hook reflects it from the first render). Removed unused `setIsLoading` and `setError`; the loading/error fields are kept in the returned shape only as future-proofing stub values (`useState(false)` / `useState(null)`) until a real fetch is wired.
3. **Re-ran `npm run lint`, `npx tsc --noEmit`, `npm run build`** — all green.

### 2026-07-13 — Aurora styling not rendering (plain HTML appearance)

**Issue:** The app appeared as unstyled HTML — no glass cards, no aurora gradients, no dark background, no button styles. The aurora design system existed in `app/globals.css` (CSS custom properties + `.aurora-*` classes) but many components bypassed it entirely by using plain Tailwind utility classes (`bg-white dark:bg-gray-700`, `text-gray-900`, `border-gray-200`, `shadow`) instead of the aurora CSS classes and custom properties (`aurora-card`, `var(--text-primary)`, `var(--glass-border)`).

**Affected components:**
- `app/features/tables/VisualTableCard.tsx` — `bg-emerald-50`, `border-gray-200`, `bg-gray-800`, `text-gray-400`
- `app/features/tables/VisualTableGrid.tsx` — `text-gray-900 dark:text-gray-50`
- `app/features/tables/TableDetailClient.tsx` — `bg-white dark:bg-gray-700`, `text-gray-900`, `border-gray-200` throughout
- `app/features/settings/SettingsPage.tsx` — `rounded-lg bg-white dark:bg-gray-700 shadow p-6`
- `app/features/dashboard/Dashboard.tsx` — `text-gray-500 dark:text-gray-300`
- `app/tables/[id]/page.tsx` — `text-gray-600 hover:underline dark:text-gray-300` (back link)

**Root cause:** Components were authored with generic Tailwind v3/v4 color utilities that have no connection to the aurora CSS variable system. When `dark:` modifiers are used with Tailwind v4's `@theme inline {}` block, they rely on the `@media (prefers-color-scheme: dark)` media query rather than the custom `dark`/`light` class toggled by `ThemeContext`. Since this app uses class-based dark mode (not `prefers-color-scheme`), the `dark:` variants never activated, and the `light:` variants don't exist in Tailwind v4 — so components appeared with Tailwind's default light-mode colors regardless of the theme toggle.

**Fixes applied:**
1. **VisualTableCard.tsx** — replaced `STATUS_CONFIG` card backgrounds (`bg-emerald-50`, etc.) with `aurora-card` as the outer container; replaced all text colors with `var(--text-primary)`, `var(--text-muted)`, `var(--text-secondary)`; replaced the "View order" / "Open" bottom link (`bg-gray-800 hover:bg-gray-700`) with `aurora-btn-primary`; replaced SVG fill colors with `var(--warning)`, `var(--success)` etc.
2. **VisualTableGrid.tsx** — replaced `text-gray-900 dark:text-gray-50` with `var(--text-primary)` and `text-gray-500 dark:text-gray-400` with `var(--text-muted)`.
3. **TableDetailClient.tsx** — replaced all `bg-white dark:bg-gray-700` card wrappers with `aurora-card p-6`; replaced all `text-gray-*` / `dark:text-gray-*` with `var(--text-primary)` / `var(--text-secondary)` / `var(--text-muted)`; replaced all `border-gray-200 dark:border-gray-600` with `border-[var(--glass-border)]`; replaced `hover:bg-gray-100 dark:hover:bg-gray-600` on quantity buttons with `hover:bg-[var(--glass-hover)]`.
4. **SettingsPage.tsx** — replaced `rounded-lg bg-white dark:bg-gray-700 shadow p-6` with `aurora-card p-6`; replaced text colors with CSS vars.
5. **Dashboard.tsx** — replaced `text-gray-500 dark:text-gray-300` and `text-gray-400 dark:text-gray-500` with `var(--text-muted)` / `var(--text-secondary)`.
6. **tables/[id]/page.tsx** — replaced back link `text-gray-600 hover:underline dark:text-gray-300` with `text-[var(--text-secondary)] hover:text-[var(--text-primary)]`.

**Verification:** `npm run lint` — clean; `npx tsc --noEmit` — clean; `npm run build` — 10/10 routes green.

### 2026-07-13 — Migration to Feature-Driven Architecture (src/ structure)

**Context:** The project was restructured from a flat `app/`-centric layout to a Feature-Driven Architecture with `src/` as the root.

**Changes:**
- `app/` moved to `src/app/` — now contains only routing pages, root layout, and globals.css
- `app/features/` moved to `src/features/` — feature modules with co-located services (auth, dashboard, menu, orders, staff, tables, settings)
- `app/components/forms/LoginForm.tsx` moved to `src/features/auth/LoginForm.tsx` (auth-specific, co-located)
- `app/services/menuItems.ts` → `src/features/menu/menuItems.ts`
- `app/services/orders.ts` → `src/features/orders/orders.ts`
- `app/services/tables.ts` → `src/features/tables/tables.ts`
- `app/services/waitresses.ts` → `src/features/staff/waitresses.ts`
- `app/components/ui/` → `src/shared/components/ui/`
- `app/components/layout/` → `src/shared/components/layout/`
- `app/contexts/` → `src/shared/contexts/`
- `app/lib/` → `src/shared/lib/`
- `app/hooks/` → `src/shared/hooks/`
- `app/services/roles.ts`, `users.ts`, `restaurants.ts` → `src/shared/services/` (cross-cutting)
- `app/styles/` and `app/assets/` (empty) — deleted
- Path alias `@/*` updated from `./*` to `./src/*` in `tsconfig.json`
- All ~38 import paths across the codebase updated accordingly
- Old `app/` directory deleted after verification
- Circular dependency between `orders.ts` and `tables.ts` updated from relative imports (`./orders` / `./tables`) to absolute (`@/features/orders/orders` / `@/features/tables/tables`)

**Verification:** `npm run lint` — clean; `npx tsc --noEmit` — clean; `npm run build` — 10/10 routes green.

## Documentation

- [`README.md`](./README.md) — public-facing overview and dev commands.
- [`PLAN.md`](./PLAN.md) — step-by-step cleanup plan with checklist (read this first if you're continuing an in-progress session).
- Next.js 16 docs are bundled in `node_modules/next/dist/docs/` — read them before writing Next.js-specific code.
