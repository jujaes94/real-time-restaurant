1:"$Sreact.fragment"
2:I[38043,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1xo729_lfztvx.js"],"Topbar"]
3:I[35198,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1xo729_lfztvx.js"],"Sidebar"]
4:I[6090,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1xo729_lfztvx.js"],"MenuPage"]
5:I[97367,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
6:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex min-h-screen flex-col relative z-10","children":[["$","$L2",null,{"title":"Menu"}],["$","div",null,{"className":"flex flex-1 overflow-hidden","children":[["$","$L3",null,{}],["$","main",null,{"className":"flex-1 overflow-auto p-6","children":["$","$L4",null,{}]}]]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/1xo729_lfztvx.js","async":true}]],["$","$L5",null,{"children":["$","$6",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Kh8TtDKo2pE2Q5ZOyL4EY"}
7:null
