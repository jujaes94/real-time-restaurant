1:"$Sreact.fragment"
2:I[9030,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1bhwywydrw5ul.js"],"default"]
3:I[97367,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/1bhwywydrw5ul.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Kh8TtDKo2pE2Q5ZOyL4EY"}
5:null
