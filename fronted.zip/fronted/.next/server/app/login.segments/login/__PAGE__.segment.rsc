1:"$Sreact.fragment"
2:I[35319,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2mgf_d63i9ma1.js"],"LoginForm"]
3:I[97367,["/_next/static/chunks/3e77nrk29e4iq.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"flex min-h-screen flex-col items-center justify-center relative z-10 px-4","children":["$","div",null,{"className":"w-full max-w-sm flex flex-col items-center gap-8","children":[["$","div",null,{"className":"text-center","children":[["$","h1",null,{"className":"text-3xl font-bold aurora-text mb-2","children":"Restaurant"}],["$","p",null,{"className":"text-sm text-[var(--text-muted)]","children":"Sign in to your workspace"}]]}],["$","div",null,{"className":"aurora-card p-6 w-full","children":["$","$L2",null,{}]}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/2mgf_d63i9ma1.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Kh8TtDKo2pE2Q5ZOyL4EY"}
5:null
