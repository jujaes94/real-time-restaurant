module.exports=[77339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tables_%5Bid%5D_page_actions_1rpulz-.js.map