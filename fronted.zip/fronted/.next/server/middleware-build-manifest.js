globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Kh8TtDKo2pE2Q5ZOyL4EY/_buildManifest.js",
    "static/Kh8TtDKo2pE2Q5ZOyL4EY/_ssgManifest.js",
    "static/Kh8TtDKo2pE2Q5ZOyL4EY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/09ozbzi9hwcvp.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/2nykiepra7i1k.js",
    "static/chunks/0mk1g55o6kl1e.js",
    "static/chunks/turbopack-1is288wqzcv1i.js"
  ]
};
